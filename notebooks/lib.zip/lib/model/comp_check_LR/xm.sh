#!/bin/bash
gnuplot -e "filename='$1'" xm.plg
